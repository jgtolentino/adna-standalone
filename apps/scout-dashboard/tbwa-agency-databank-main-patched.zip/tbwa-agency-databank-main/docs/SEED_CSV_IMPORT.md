# Scout Seed CSV Import

This repo includes **schema-aligned** seed CSVs for `scout.regions`, `scout.stores`, and `scout.transactions`.

## Files

- `data/seed/regions.csv`
- `data/seed/demo/stores.csv`
- `data/seed/demo/transactions.csv` (3,500 rows / 30-day window)
- `data/seed/prod/stores.csv`
- `data/seed/prod/transactions.csv` (18,000 rows / 365-day window)

Regenerate anytime:

```bash
python3 scripts/generate_scout_seed_csv.py --mode demo
python3 scripts/generate_scout_seed_csv.py --mode prod
```

## Import via psql (fast + reproducible)

Assumptions:
- You have a Postgres connection string in `DATABASE_URL` (Supabase local or remote).
- `scout` schema + tables already exist (run migrations first).

```bash
# Example: export DATABASE_URL='postgresql://postgres:postgres@127.0.0.1:54322/postgres'
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<'SQL'
\copy scout.regions(code,name,island_group) FROM 'data/seed/regions.csv' CSV HEADER
SQL
```

Stores + transactions:

```bash
# DEMO
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<'SQL'
\copy scout.stores(id,store_code,store_name,region_code,province,city,barangay,store_type,lat,lon,created_at) FROM 'data/seed/demo/stores.csv' CSV HEADER
\copy scout.transactions(
  id,store_id,timestamp,time_of_day,region_code,province,city,barangay,
  brand_name,sku,product_category,product_subcategory,our_brand,tbwa_client_brand,
  quantity,unit_price,gross_amount,discount_amount,payment_method,
  customer_id,age,gender,income,urban_rural,funnel_stage,basket_size,
  repeated_customer,request_type,suggestion_accepted,substitution_occurred,created_at
) FROM 'data/seed/demo/transactions.csv' CSV HEADER
SQL
```

```bash
# PROD
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<'SQL'
\copy scout.stores(id,store_code,store_name,region_code,province,city,barangay,store_type,lat,lon,created_at) FROM 'data/seed/prod/stores.csv' CSV HEADER
\copy scout.transactions(
  id,store_id,timestamp,time_of_day,region_code,province,city,barangay,
  brand_name,sku,product_category,product_subcategory,our_brand,tbwa_client_brand,
  quantity,unit_price,gross_amount,discount_amount,payment_method,
  customer_id,age,gender,income,urban_rural,funnel_stage,basket_size,
  repeated_customer,request_type,suggestion_accepted,substitution_occurred,created_at
) FROM 'data/seed/prod/transactions.csv' CSV HEADER
SQL
```

## Quick verification queries

```sql
select count(*) as regions from scout.regions;
select count(*) as stores from scout.stores;
select count(*) as tx from scout.transactions;
select product_category, count(*) from scout.transactions group by 1 order by 2 desc;
select region_code, count(*) from scout.transactions group by 1 order by 2 desc;
```
