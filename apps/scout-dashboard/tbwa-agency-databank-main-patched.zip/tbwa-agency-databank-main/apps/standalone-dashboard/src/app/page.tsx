import { DatabankPage } from '@/components/databank/DatabankPage';

export default function HomePage() {
  return <DatabankPage />;
}