/**
 * Scout XI Types - Barrel Export
 */

// Databank types (legacy)
export * from './databank';

// Scout canonical types (new schema)
export * from './scout';
