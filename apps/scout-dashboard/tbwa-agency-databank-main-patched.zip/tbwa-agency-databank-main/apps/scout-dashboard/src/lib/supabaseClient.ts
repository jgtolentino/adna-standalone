import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { env } from './env';

// Use validated env when available; fall back to process.env (CI) and then to placeholders.
const url =
  env.NEXT_PUBLIC_SUPABASE_URL ??
  process.env.NEXT_PUBLIC_SUPABASE_URL ??
  'https://placeholder.supabase.co';

const anon =
  env.NEXT_PUBLIC_SUPABASE_ANON_KEY ??
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ??
  'placeholder-anon-key';

// Singleton client - one global instance, no duplicates
let _client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (!_client) {
    _client = createClient(url, anon, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return _client;
}

/**
 * Get a Supabase client configured for a specific schema
 * This is needed because the scout tables are in the 'scout' schema
 */
export function getSupabaseSchema(schemaName: string = 'scout'): SupabaseClient {
  const client = getSupabase();
  // Use type assertion since schema() returns a new client with different type
  return (client as any).schema(schemaName) as SupabaseClient;
}

// Helper to check if using real Supabase or placeholder
export function isSupabaseConfigured(): boolean {
  const isUrlPlaceholder = url === 'https://placeholder.supabase.co';
  const isAnonPlaceholder = anon === 'placeholder-anon-key';
  return !(isUrlPlaceholder || isAnonPlaceholder);
}
